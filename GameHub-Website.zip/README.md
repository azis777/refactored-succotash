# GameHub

Website game orisinal dengan:
- Login demo
- Registrasi demo
- Dashboard
- Daftar game dan pencarian
- Profil pengguna
- Responsive design

## Cara upload ke GitHub Pages
1. Buat repository baru di GitHub.
2. Upload `index.html`, `style.css`, dan `script.js`.
3. Buka Settings → Pages.
4. Pilih Deploy from a branch.
5. Pilih branch `main` dan folder `/root`.
6. Simpan, lalu buka URL GitHub Pages.

Catatan: autentikasi menggunakan localStorage untuk demo. Jangan gunakan untuk menyimpan data sensitif atau produksi.
